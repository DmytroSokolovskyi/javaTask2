The data files in this directory were obtained from the public IANA time zone database,
https://www.iana.org/time-zones, see pom.xml for the version.
